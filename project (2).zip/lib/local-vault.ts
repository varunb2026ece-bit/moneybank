const DATABASE_NAME = 'spendwise-local-vault'
const DATABASE_VERSION = 1
const VAULT_STORE = 'vault'
const DATA_KEY = 'encrypted-data'
const CONFIG_KEY = 'config'
const KDF_ITERATIONS = 600_000
const VERIFIER_TEXT = 'spendwise-vault-key-check-v1'

export type Profile = { id: string; full_name: string; created_at: string }
export type Category = { id: string; profile_id: string; name: string; kind: 'income' | 'expense'; color: string }
export type Transaction = { id: string; user_id: string; title: string; amount: number; kind: 'income' | 'expense'; category: string; payment_method: string; occurred_on: string; description: string; created_at: string; updated_at: string }
export type Budget = { id: string; user_id: string; name: string; amount: number; month: string; category: string | null }
export type Goal = { id: string; user_id: string; name: string; target_amount: number; target_date: string | null; created_at: string }
export type Contribution = { user_id: string; goal_id: string; amount: number; contributed_on: string; note: string }
export type VaultData = { profiles: Profile[]; categories: Category[]; transactions: Transaction[]; budgets: Budget[]; goals: Goal[]; contributions: Contribution[] }
type VaultConfig = { salt: string; verifierIv: string; verifier: string; iterations: number }
type EncryptedData = { iv: string; ciphertext: string }
export type EncryptedBackup = { format: 'spendwise-encrypted-backup'; version: 1; config: VaultConfig; data: EncryptedData }

function validateConfig(value: unknown): asserts value is VaultConfig {
  if (!value || typeof value !== 'object') throw new Error('This backup has an invalid vault configuration.')
  const config = value as Partial<VaultConfig>
  if (typeof config.salt !== 'string' || typeof config.verifierIv !== 'string' || typeof config.verifier !== 'string' || !Number.isSafeInteger(config.iterations) || config.iterations! < 100_000 || config.iterations! > 2_000_000) throw new Error('This backup has an invalid vault configuration.')
  try {
    if (decode(config.salt).length !== 16 || decode(config.verifierIv).length !== 12 || decode(config.verifier).length < 16) throw new Error()
  } catch { throw new Error('This backup has an invalid vault configuration.') }
}

function validateEncryptedData(value: unknown): asserts value is EncryptedData {
  if (!value || typeof value !== 'object' || typeof (value as Partial<EncryptedData>).iv !== 'string' || typeof (value as Partial<EncryptedData>).ciphertext !== 'string') throw new Error('This backup does not contain valid encrypted data.')
  try {
    if (decode((value as EncryptedData).iv).length !== 12 || decode((value as EncryptedData).ciphertext).length < 16) throw new Error()
  } catch { throw new Error('This backup does not contain valid encrypted data.') }
}

const initialProfiles: Profile[] = [
  { id: '1d1412d6-9b88-4bef-9d42-b56baa13be2b', full_name: 'zaria', created_at: '2026-11-18T11:52:38.498Z' },
  { id: 'dbaabb6c-7e25-4035-842e-b208225ec82f', full_name: 'zaria', created_at: '2026-11-18T11:54:35.275Z' },
]
const categoryDefinitions = [
  ['6f6d9ac0-1ed6-4c2e-848c-901af96f1bda', '109cc0ee-a16c-4b4b-bc2f-5e2c2f08e07b', 'Food & Dining', 'expense', '#F97316'],
  ['e839efd7-dfdb-424b-9663-22b26f73117a', '346e8f09-00c3-4ac4-af67-806bd6fb9f34', 'Freelance', 'income', '#22D3EE'],
  ['1b82960a-153b-4aac-bcdc-af9abd5290f7', 'fd773cb1-f073-4603-81c0-c5cb702c7f47', 'Housing', 'expense', '#60A5FA'],
  ['60afd275-4604-4c0e-8aec-5e7c0c6a7a65', 'a2bf32c5-a4fa-457a-9ad1-105fadcd1852', 'Other', 'expense', '#94A3B8'],
  ['e8d33b67-6afd-42f1-ad2d-47f811451f79', 'e03e9256-2568-4736-a732-f1ea3627010b', 'Salary', 'income', '#10B981'],
  ['3d85fb18-96e4-4a42-810b-2965580481ae', '09d8b728-bd0a-4d66-9ed5-2c5ffd6325a9', 'Shopping', 'expense', '#F472B6'],
  ['584ef983-1f7f-49f2-855e-990b39a98042', 'c7d24f2b-6be0-4a70-9448-8b9e215bf34e', 'Transport', 'expense', '#A78BFA'],
] as const
const initialCategories: Category[] = categoryDefinitions.flatMap(([firstId, secondId, name, kind, color]) => [
  { id: firstId, profile_id: initialProfiles[0].id, name, kind, color },
  { id: secondId, profile_id: initialProfiles[1].id, name, kind, color },
])

export const emptyVaultData = (): VaultData => ({ profiles: [], categories: [], transactions: [], budgets: [], goals: [], contributions: [] })
export const migratedVaultData = (): VaultData => ({ profiles: structuredClone(initialProfiles), categories: structuredClone(initialCategories), transactions: [], budgets: [], goals: [], contributions: [] })

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION)
    request.onupgradeneeded = () => request.result.createObjectStore(VAULT_STORE)
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error ?? new Error('Could not open local storage.'))
    request.onblocked = () => reject(new Error('Local storage is busy in another tab. Close other SpendWise tabs and try again.'))
  })
}
function requestResult<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => { request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error ?? new Error('Local storage request failed.')) })
}
async function readValue<T>(key: string): Promise<T | undefined> {
  const db = await openDatabase()
  try { return await requestResult<T | undefined>(db.transaction(VAULT_STORE, 'readonly').objectStore(VAULT_STORE).get(key)) }
  finally { db.close() }
}
async function writeValues(values: Array<[string, unknown]>): Promise<void> {
  const db = await openDatabase()
  try {
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction(VAULT_STORE, 'readwrite')
      const store = transaction.objectStore(VAULT_STORE)
      values.forEach(([key, value]) => store.put(value, key))
      transaction.oncomplete = () => resolve()
      transaction.onerror = () => reject(transaction.error ?? new Error('Could not save encrypted data.'))
      transaction.onabort = () => reject(transaction.error ?? new Error('Saving encrypted data was cancelled.'))
    })
  } finally { db.close() }
}
const encode = (bytes: Uint8Array) => {
  let binary = ''
  for (let offset = 0; offset < bytes.length; offset += 0x8000) binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000))
  return btoa(binary)
}
const decode = (value: string) => Uint8Array.from(atob(value), character => character.charCodeAt(0))
const randomBytes = (length: number) => crypto.getRandomValues(new Uint8Array(length))

async function deriveKey(passphrase: string, salt: Uint8Array, iterations = KDF_ITERATIONS): Promise<CryptoKey> {
  const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(passphrase.normalize('NFKC')), 'PBKDF2', false, ['deriveKey'])
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations, hash: 'SHA-256' }, material, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt'])
}
async function encryptData(key: CryptoKey, data: VaultData): Promise<EncryptedData> {
  const iv = randomBytes(12)
  const plaintext = new TextEncoder().encode(JSON.stringify(data))
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, plaintext)
  return { iv: encode(iv), ciphertext: encode(new Uint8Array(encrypted)) }
}
async function decryptData(key: CryptoKey, encrypted: EncryptedData): Promise<VaultData> {
  validateEncryptedData(encrypted)
  const plaintext = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: decode(encrypted.iv) }, key, decode(encrypted.ciphertext))
  const data = JSON.parse(new TextDecoder().decode(plaintext)) as VaultData
  if (!data || !Array.isArray(data.profiles) || !Array.isArray(data.categories) || !Array.isArray(data.transactions) || !Array.isArray(data.budgets) || !Array.isArray(data.goals) || !Array.isArray(data.contributions)) throw new Error('This backup does not contain a valid SpendWise vault.')
  return data
}
async function verifyPassphrase(key: CryptoKey, config: VaultConfig): Promise<void> {
  validateConfig(config)
  try {
    const plaintext = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: decode(config.verifierIv) }, key, decode(config.verifier))
    if (new TextDecoder().decode(plaintext) !== VERIFIER_TEXT) throw new Error('Incorrect passphrase.')
  } catch { throw new Error('Incorrect passphrase. Please try again.') }
}
async function createConfig(passphrase: string): Promise<{ config: VaultConfig; key: CryptoKey }> {
  const salt = randomBytes(16)
  const verifierIv = randomBytes(12)
  const key = await deriveKey(passphrase, salt)
  const verifier = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: verifierIv }, key, new TextEncoder().encode(VERIFIER_TEXT))
  return { config: { salt: encode(salt), verifierIv: encode(verifierIv), verifier: encode(new Uint8Array(verifier)), iterations: KDF_ITERATIONS }, key }
}

export async function hasVault(): Promise<boolean> { return Boolean(await readValue<VaultConfig>(CONFIG_KEY)) }
export async function createVault(passphrase: string): Promise<{ key: CryptoKey; data: VaultData }> {
  if (await hasVault()) throw new Error('A local vault already exists. Unlock it instead.')
  if (passphrase.length < 12) throw new Error('Choose a passphrase with at least 12 characters.')
  const data = migratedVaultData()
  const { config, key } = await createConfig(passphrase)
  const encrypted = await encryptData(key, data)
  await writeValues([[CONFIG_KEY, config], [DATA_KEY, encrypted]])
  return { key, data }
}
export async function unlockVault(passphrase: string): Promise<{ key: CryptoKey; data: VaultData }> {
  const config = await readValue<VaultConfig>(CONFIG_KEY)
  const encrypted = await readValue<EncryptedData>(DATA_KEY)
  if (!config || !encrypted) throw new Error('Local vault data is missing. Import an encrypted backup or set up a new vault.')
  validateConfig(config)
  validateEncryptedData(encrypted)
  const key = await deriveKey(passphrase, decode(config.salt), config.iterations)
  await verifyPassphrase(key, config)
  return { key, data: await decryptData(key, encrypted) }
}
export async function saveVault(key: CryptoKey, data: VaultData): Promise<void> {
  const encrypted = await encryptData(key, data)
  await writeValues([[DATA_KEY, encrypted]])
}
export async function exportEncryptedBackup(): Promise<EncryptedBackup> {
  const [config, data] = await Promise.all([readValue<VaultConfig>(CONFIG_KEY), readValue<EncryptedData>(DATA_KEY)])
  if (!config || !data) throw new Error('No local vault backup is available.')
  return { format: 'spendwise-encrypted-backup', version: 1, config, data }
}
export async function importEncryptedBackup(backup: unknown, passphrase: string, replaceExisting = false): Promise<{ key: CryptoKey; data: VaultData }> {
  if (!backup || typeof backup !== 'object' || !('format' in backup) || backup.format !== 'spendwise-encrypted-backup' || !('version' in backup) || backup.version !== 1 || !('config' in backup) || !('data' in backup)) throw new Error('This file is not a supported encrypted SpendWise backup.')
  const envelope = backup as EncryptedBackup
  validateConfig(envelope.config)
  validateEncryptedData(envelope.data)
  const existing = await hasVault()
  if (existing && !replaceExisting) throw new Error('A local vault already exists. Unlock it before importing a replacement backup.')
  const key = await deriveKey(passphrase, decode(envelope.config.salt), envelope.config.iterations)
  await verifyPassphrase(key, envelope.config)
  const data = await decryptData(key, envelope.data)
  await writeValues([[CONFIG_KEY, envelope.config], [DATA_KEY, envelope.data]])
  return { key, data }
}
