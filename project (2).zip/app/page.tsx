import SpendWiseApp from '@/components/spendwise-app'

export default function Page() {
  return <SpendWiseApp />
}
